const clock = document.querySelector("#datetime-clock");

function setClock() {
    const datetime = new Date();
    let hour = datetime.getHours();
    let minute = datetime.getMinutes();
    let second = datetime.getSeconds();

    function convertTwoDigit(digit) {
        condition = digit <= 9;
        twoDigit = condition ? `0${digit}` : digit;

        return twoDigit;
    }

    hour = convertTwoDigit(hour);
    minute = convertTwoDigit(minute);
    second = convertTwoDigit(second);

    let time = `${hour}:${minute}:${second}`

    clock.innerText = time;
};

function init() {
    setInterval(setClock, 1000);
};

init();