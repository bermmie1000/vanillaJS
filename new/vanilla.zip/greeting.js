const message = document.querySelector("#greeting-message"),
    input = document.querySelector("#greeting-input");

const LOCALSTORAGE_USER = "currentUser";

function saveName(text) {
    localStorage.setItem(LOCALSTORAGE_USER, text);
}

function paintName(text) {
    message.innerText = `Hello ${text}`;
}

function handleSubmit(event) {
    event.preventDefault();
    const name = input.value;
    paintName(name);
}


function askForName() {
    input.addEventListener("submit", handleSubmit);
}

function loadName() {
    const currentUser = localStorage.getItem(LOCALSTORAGE_USER);
    if (currentUser === null) {
        askForName();
    } else {
        paintName(currentUser);
    }
}

function init() {
    loadName();
}

init();